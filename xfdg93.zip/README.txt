change input file by changing FILENAME variable inside python file

install requirements with pip install -r requirements.txt

Grammar is output to grammar.txt


graphviz is required to run this program
